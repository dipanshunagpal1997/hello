import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;


public class client {

	static String name1, name2;
	static int ch;
	public static void main(String[] args) {
		client c = new client();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		try {
			Registry r = LocateRegistry.getRegistry("localhost",6000);
			DBint d = (DBint)r.lookup("DBserv");
			do
			{
				System.out.println("\n 1. Reverse the String\n 2. Concatenate two strings\n 3. Calculate length of String\n 4. String Compare\n 5. Substring\n 6. Palindrome\n 7. Exit\n Enter your choice: ");
				ch = Integer.parseInt(br.readLine());
				switch (ch) {
				case 1:
					System.out.println("Enter name: ");
					name1 = br.readLine();
					name1 = d.strrev(name1);
					System.out.println(name1);
					break;
				
				case 2:	System.out.println("Enter String 1: ");
					name1 = br.readLine();
					System.out.println("Enter String 2: ");
					name2 = br.readLine();
					name2 = d.concat(name1,name2);
					System.out.println("String: "+name2);
					break;

				case 3:	System.out.println("Enter String 1: ");
					name1 = br.readLine();
					int len = d.strlen(name1);						
					System.out.println("Length: "+len);
					break;
				
				case 4:	System.out.println("Enter String 1: ");
					name1 = br.readLine();
					System.out.println("Enter String 2: ");
					name2 = br.readLine();
					if((d.strcmp(name1,name2))==0)
						System.out.println("String Match ..!!");
					else
						System.out.println("String Not Match ..!!");
					break;
			
				case 5:	System.out.println("Enter String 1: ");
					name1 = br.readLine();
					System.out.println("Enter String 2: ");
					name2 = br.readLine();
					if(d.substr(name1,name2))
						System.out.println("True..!!");
					else
						System.out.println("False ..!!");
					break;
		
				case 6:	System.out.println("Enter String 1: ");
					name1 = br.readLine();
					if((d.palindrome(name1))==0)
						System.out.println("Palindrome ..!!");
					else
						System.out.println("String Not Palindrome ..!!");
					break;
				
				case 7: System.exit(0);
					break;
				}
			}while(ch>0);
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}

