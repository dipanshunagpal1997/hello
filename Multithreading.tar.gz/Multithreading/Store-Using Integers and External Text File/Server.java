import java.io.*;
import java.net.*;
import java.lang.*;

public class Server {

	public static void main(String[] args) throws IOException {
		final int port = 1334;
		System.out.println("Server waiting for connection on port "+port);
		ServerSocket ss = new ServerSocket(port);
		Socket clientSocket = ss.accept();
		System.out.println("Recieved connection from "+clientSocket.getInetAddress()+" on port "+clientSocket.getPort());
		//create two threads to send and recieve from client
		RecieveFromClientThread recieve = new RecieveFromClientThread(clientSocket);
		Thread thread = new Thread(recieve);
		thread.start();

		SendToClientThread send = new SendToClientThread(clientSocket);
		Thread thread2 = new Thread(send);
		thread2.start();
	}}

class RecieveFromClientThread implements Runnable
{
	Socket clientSocket=null;
	BufferedReader brBufferedReader = null;
	static int i=0,j=0;
	public RecieveFromClientThread(Socket clientSocket)
	{
		this.clientSocket = clientSocket;
	}//end constructor
	public void run() {
		try{
		brBufferedReader = new BufferedReader(new InputStreamReader(this.clientSocket.getInputStream()));		
		
		String messageString;
		while(true){
		while((messageString = brBufferedReader.readLine())!= null){//assign message from client to messageString
			if(messageString.equals("EXIT"))
			{
				break;//break to close socket if EXIT
			}
			
			i=Integer.parseInt(messageString);
			j=j+i;
			System.out.println("New Bill Amount is " + j);//print the message from client
			PrintWriter writer = new PrintWriter("Buffer.txt", "UTF-8");
			writer.println("Total Bill is "+j);
			
			writer.close();
		}
		System.out.println("Total Bill Amount is " + j);
		this.clientSocket.close();
		System.exit(0);
	}
		
	}
	catch(Exception ex){System.out.println(ex.getMessage());}
	}
}//end class RecieveFromClientThread

class SendToClientThread implements Runnable
{
	PrintWriter pwPrintWriter;
	Socket clientSock = null;
	
	public SendToClientThread(Socket clientSock)
	{
		this.clientSock = clientSock;
	}
	public void run() {
		try{
		pwPrintWriter =new PrintWriter(new OutputStreamWriter(this.clientSock.getOutputStream()));//get outputstream
		
		while(true)
		{
			String msgToClientString = null;
			BufferedReader input = new BufferedReader(new InputStreamReader(System.in));//get userinput
			System.out.println("Enter yes to add more Bill amount");
			msgToClientString= input.readLine();
			//File file = new File("Buffer.txt");
 
		       // BufferedReader br = new BufferedReader(new FileReader(file));
		 
		   	//String st;
		  	//st = br.readLine();
		  	if(msgToClientString.equals("yes"))
		  	{
		  	pwPrintWriter.println(RecieveFromClientThread.j);//send message to client with PrintWriter
			
			pwPrintWriter.flush();//flush the PrintWriter
			}
			//msgToClientString = input.readLine();//get message to send to client
			
			
			
		}//end while
		}
		catch(Exception ex){System.out.println(ex.getMessage());}	
	}//end run
}//end class SendToClientThread





/*
OUTPUT:-
root@info17-HP-280-G2-MT:/home/info17/Desktop# java Server
Server waiting for connection on port 1334
Recieved connection from /127.0.0.1 on port 44602
Enter yes to send addition
yes
Enter yes to send addition
Addition is 1
Addition is 3
Addition is 8
Addition is 15
yes
Enter yes to send addition

*/

