



#include "fact.h"
int *
fact_1_svc(intpair *argp, struct svc_req *rqstp)
{
static int result,n,fact;
int i,a,b,c,count;
n=argp->a;
// factorial logic
fact = 1;
count=0;

a = 0;
    b = 1;
    c = 0;

    printf("\nFibonacci terms: \n");

    /* Iterate through n terms */
    for(i=1; i<=n; i++)
    {
        printf("%d  ", c);
	count=count+c;
        a = b;     // Copy n-1 to n-2
        b = c;     // Copy current to n-1
        c = a + b; 
        // New term
	//count++;    
    }
    
    
/*printf("\n Received : n= %d \n",n);
for (i=n;i>0;i--)
{
fact=fact * i;
}*/
result=count;
return &result;
}




/*
OUTPUT:-
info17@info17-HP-280-G2-MT:~/Desktop/exp2$ sudo ./fact_server

 Received : n= 5 

 Received : n= 6 
*/
