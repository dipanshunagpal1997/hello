import java.rmi.*;
import java.rmi.server.*;

interface DBint extends Remote
{
	public String strrev(String name1) throws RemoteException;
	public String concat(String name1,String name2)	throws RemoteException;
	public int strlen(String name1) throws RemoteException;
	public int strcmp(String name1, String name2) throws RemoteException;
	public boolean substr(String name1, String name2) throws RemoteException;
	public int palindrome(String name1) throws RemoteException;
}

public class server extends UnicastRemoteObject implements DBint{

	public server() throws RemoteException {
		System.out.println("Server Ready");
	}

	public static void main(String[] args) {
		try {
			server s = new server();
			java.rmi.registry.LocateRegistry.createRegistry(6000).bind("DBserv", s);
		} catch (Exception e) {	}
	}
	
	public String strrev(String name1)
	{
		return (new StringBuffer(name1).reverse().toString());		
	}

	public String concat(String name1,String name2)
	{
		return name1.concat(name2);	
	}

	public int strlen(String name1)
	{
		return name1.length();
	}

	public int strcmp(String name1, String name2)
	{
		return name1.compareTo(name2);
	}
	
	public boolean substr(String name1, String name2)
	{
		return name1.contains(name2);
	}

	public int palindrome(String name1)
	{
		String name3 = strrev(name1);
		return strcmp(name3,name1);
	}
}

